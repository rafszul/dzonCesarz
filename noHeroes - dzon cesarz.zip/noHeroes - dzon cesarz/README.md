noHeroes: dzon cesarz: story of a man who traded water
=========

noHeroes: dzon cesarz: story of a man who traded water

##noHeros

is a follow up to [#transeuropacaravans](http://citizenspact.eu/) and [#bleach_v16_62](https://github.com/rafszul/-bleach_v16_62) and a web tech based take on new-generation-multiplayer-rpg-games in form of interactive web comic with storyline based on real life events transported to dystopian world of europe in mid 21 century.

initially the game was intended for 30-35 people taking part in [#transeuropacaravans](http://citizenspact.eu/) an initiative by [european altenatives](http://www.euroalter.com/) which involved six teams traveling in caravans accross europe visiting various locations and interacting with various forms of organised discontent.

as a teaser see img gallery from materials used on [characterTemplate](http://bleachv1662.businesscatalyst.com/)


check out [background to the story with some hints at general mechanics prepared for the crews](http://bleachv1662.tumblr.com/post/82381253923/background-to-the-story-the-main-activity)

   
links:

github repo  with [intro to #bleach_v16_62](https://github.com/rafszul/-bleach_v16_62) - the web page is an unoptimised export from original EgAn composition by [weAreThePlayMakers](http://wearetheplaymakers.com/)

the credits included on the final page
 
[european altenatives](http://www.euroalter.com/)

[Dragdealer.js 0.9.7](http://github.com/skidding/dragdealer) by Ovidiu Cherecheș

composition based on demo by [Codrops 2014](http://www.codrops.com)
